EMIL MARGARYAN — MISE À JOUR RUSSE FINALE

À envoyer à la RACINE du dépôt GitHub emilmark :

REMPLACER :
- index.html
- index-en.html
- story-last-word-fr.html
- story-last-word-en.html

AJOUTER :
- index-ru.html
- story-last-word-ru.html

Aucun fichier du dossier assets n'est à modifier.
Les images existantes restent les mêmes.

Cette étape ajoute :
- le sélecteur FR / EN / RU ;
- la page d'accueil russe ;
- la version russe définitive de « Le dernier mot / Последнее слово ».

Les quatre autres nouvelles sont déjà présentées en russe sur l'accueil,
mais leur traduction russe intégrale sera ajoutée progressivement.
